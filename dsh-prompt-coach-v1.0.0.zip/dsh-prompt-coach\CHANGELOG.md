# Changelog

## 1.0.0 — 2026-11-12

首个公开版本。

### 新增
- 技能 `prompt-writing-coach`：自动识别 → 选框架 → 出成品；含易混对判据、开发/短视频速查、带教要点。
- 工具 `prompt_scaffold`：确定性选型（固定 5 问顺序 + 视频信号），生成 RTF / ICIO / CO-STAR / CRISPE / CoT / ToT / AIDA / PAS / BROKE / VIDEO7 十种骨架。
- 输出固定附：使用说明 / 可调参数 / 避坑提醒。
- 随包 references：选型判据表、框架总目录、代写服务契约、教学要点、实战案例。

### 已知限制
- 选型是规则驱动，不做语义理解；遇到边界模糊的需求时，应追问一个业务问题（技能里已写该规则）。
- 仅支持 DSH 插件体系（cordis 公开扩展点），未适配其他 harness。
