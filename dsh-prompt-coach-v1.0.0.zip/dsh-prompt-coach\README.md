# dsh-prompt-coach

> 让 AI 只看你的一句需求，就自动选对提示词框架，直接给出能复制的提示词。
> 你永远不需要知道 RTF、CO-STAR、CoT 这些名字。

一个 DeepSeek Harness（DSH）插件：装一次，技能与工具全局可用。

---

## 为什么做这个

大多数人写不好提示词，不是因为不会写，而是因为**不知道该用哪种结构**：
有资料该怎么问、卖东西该怎么开头、要推理该怎么约束、没标准答案该怎么发散。

这个插件把「选框架」这件事从用户身上拿走：

- 用户只描述「想做出什么效果、按什么方式」；
- 插件按**固定判定顺序**自动选框架；
- 直接产出可复制粘贴的成品提示词。

同一个需求永远是同一个结果——因为它用的是确定性的规则，不是模型临场猜。

---

## 两个能力

### 1. 技能：`prompt-writing-coach`
随包携带，安装后进入技能库。任何会话提到「写提示词 / 选框架 / 短视频脚本 / 开发提示词」时自动触发。
技能内含：自动识别流程、易混对判据、软件开发 10 类、短视频 6 类 + AI 视频 7 段结构、带教 10 讲。

### 2. 工具：`prompt_scaffold`
模型可直接调用的函数工具。传一句需求，返回：

- 选中的框架 + **一句话理由**（为什么是它）
- 可直接复制的提示词骨架（变量用 `{{}}`）
- 使用说明 / 可调参数 / 避坑提醒

纯本地规则、零依赖、不联网。

---

## 判定顺序（固定，不凭感觉）

```
第 1 问：有没有必须依据的外部材料？  有 → ICIO
第 2 问：是不是为了卖东西/促转化？    是 → AIDA（陌生流量）/ PAS（已知痛点）
第 3 问：要不要推理/判断/可核对？     是 → CoT
第 4 问：要不要多方案比选？           是 → ToT
第 5 问：要不要定目标/拆验收？        是 → BROKE
        都不命中 → 默认 RTF
```

另外命中视频生成信号（画面/镜头/出片）时走 `VIDEO7`（7 段视频提示词结构）。

### 易混对口诀

> **有料 ICIO，没料 RTF；定调 CO-STAR，分身 CRISPE；**
> **陌生 AIDA，痛点 PAS；一条 CoT，多条 ToT；**
> **动手 ReAct，引用 RAG；选路 ToT，交活 CRISPE；**
> **目标 BROKE，汇报 SCQA。**

---

## 安装

### 方式一：插件面板（推荐）
DSH → 插件 → 添加插件 → 填本地目录路径：

```
<本仓库所在的绝对路径>
```

（插件包已含 `package.json` 与 `cordis.patch.yml`，面板可直接识别。）

### 方式二：命令行
```bash
dsh plugin --profile desktop add <本仓库绝对路径>
```

### 方式三：手动
把本目录加入 profile 的依赖（`link:` 或 `file:`）并加入 `dsh.profile.bundles`，然后 `pnpm install`。
改 profile 配置前请先备份。

> 安装后**热生效**，无需重启 DSH。

---

## 使用

### 直接说需求（技能自动触发）
> 把这段会议记录整理成待办清单

预期：选 **ICIO**，并自动带「只依据输入、未提及写未提及、矛盾要指出」三句护身符。

> 卖一款保温杯，给刷到视频的陌生人

预期：选 **AIDA**，带黄金 3 秒钩子 + 字数/语速/禁用词约束。

### 显式调用工具
```json
{
  "requirement": "把这段聊天记录整理成周报",
  "material": "（粘贴原文）",
  "audience": "直属领导，用于周一晨会",
  "constraints": "不超过 400 字；只写完成事项与风险",
  "domain": "general"
}
```
可选参数 `framework` 强制指定（`RTF` / `ICIO` / `CO-STAR` / `CRISPE` / `CoT` / `ToT` / `AIDA` / `PAS` / `BROKE` / `VIDEO7`）。

---

## 在别的 AI / Agent 上用（不需要装插件）

插件装在 DeepSeek Harness 里；但**同一套规则可以搬到任何 AI** 上。看对方支持什么，选对应文件：

| 对方是什么 | 放哪个文件 | 放在哪 |
|---|---|---|
| Claude Code / 任何支持 SKILL.md 的 agent | 整个 `skills/prompt-writing-coach/` 文件夹 | `~/.claude/skills/`（SKILL.md 要在文件夹第一层） |
| ChatGPT / 豆包 / 通义 / 文心 / 元宝 / Claude 网页版 | `skills/prompt-writing-coach/portable/system-prompt.md` | 自定义指令 / 系统提示 / 项目指令 |
| 有字数限制的平台（多数国内 AI） | `.../portable/system-prompt-lite.md`（精简版约 1 KB） | 同上 |
| Cursor / Windsurf | `.../portable/cursor-rule.mdc` | `.cursor/rules/` 或 `.windsurf/rules/` |
| Coze（扣子）/ Dify / 智能体平台 | `.../portable/system-prompt.md` | 人设与回复逻辑 / 系统提示词 |

**不要放的文件**：`lib/index.js`、`package.json`、`cordis.patch.yml`——这些是插件程序本体，只有 DeepSeek Harness 能识别。

**最省事的兜底**：任何一个只有聊天框的 AI，把 `portable/system-prompt-lite.md` 全文贴进对话开头，说"按这个规则帮我"，也能用个七七八八。

---

## 验证清单

| 输入 | 期望框架 |
|---|---|
| 把这段会议纪要整理成待办清单 | ICIO |
| 帮我写个待办清单模板 | RTF |
| 卖保温杯，给刷到视频的陌生人 | AIDA |
| 家长焦虑孩子粗心，卖错题本 | PAS |
| 这几个方向哪个好，帮我比选 | ToT |
| 算一下报价对不对，要能核对 | CoT |
| 把年度目标拆成季度 KR | BROKE |
| 雨夜霓虹街道，镜头缓慢推近 | VIDEO7 |
| 写个 Java 接口加 Redis 缓存 | RTF |

关键边界测试：**「帮我把这些东西弄成能用的」→ RTF；「帮我把这段东西弄成能用的」→ ICIO**（多一个"这段"，就从创作变成资料加工）。

---

## 目录结构

```
dsh-prompt-coach/
├── package.json              插件清单（dsh.bundle.patch 指向补丁）
├── cordis.patch.yml          把自己插入 profile 的插件清单
├── lib/index.js              实现：技能提供者 + prompt_scaffold 工具
├── skills/prompt-writing-coach/
│   ├── SKILL.md              随包技能
│   ├── references/           选型判据 / 框架总目录 / 契约 / 教学 / 实战案例
│   └── portable/             通用 system prompt 与 Cursor 规则（可单独用）
├── docs/EXAMPLES.md          输出样例
├── CHANGELOG.md
├── LICENSE
└── README.md
```

---

## 兼容性

- 运行在 DeepSeek Harness（cordis 插件体系），只使用公开扩展点：`ctx.skills`、`ctx.tools`；
- 不改 DSH 核心，不引入运行时依赖；
- 要求 Node.js ≥ 20（ESM）。

---

## 卸载

插件面板卸载，或：

```bash
dsh plugin --profile desktop remove dsh-prompt-coach
```

---

## 开发

```bash
node --input-type=module -e "const m=await import('./lib/index.js'); console.log(m.name, m.inject)"
```

改完规则后建议跑一遍「验证清单」里的 9 条用例。

---

## License

MIT
