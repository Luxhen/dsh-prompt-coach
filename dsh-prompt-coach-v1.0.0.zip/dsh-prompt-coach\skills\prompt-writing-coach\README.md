# prompt-writing-coach · 安装说明

> 版本：v1.0　打包日期：2026-11-12
> 作用：让任何支持"技能 / 系统提示 / 自定义指令"的 AI，都学会「按你的话自动选框架、直接写出成品提示词」。
> 特点：**用户只说效果，不问框架名**；内置易混对判据，降低选错概率。

---

## 包内结构

```
prompt-writing-coach/
├── SKILL.md                    ← 主文件（Claude / DSH 技能格式，含 frontmatter）
├── README.md                   ← 本安装说明
├── portable/
│   ├── system-prompt.md        ← 通用版：任何能改系统提示/自定义指令的 AI
│   └── cursor-rule.mdc         ← Cursor / Windsurf 等 IDE 的规则文件
└── references/
    ├── 选型判据表.md            ← 易混对判据完整版
    ├── 框架总目录.md            ← 全部框架速查
    ├── 代写服务契约.md          ← 下单方式与领域速查
    ├── 教学要点.md              ← 8 讲课程与自查清单
    └── 实战案例.md              ← 0–8 步改造案例
```

> `SKILL.md` 是自包含的：不依赖 references 也能干活；references 只是深读材料。

---

## 安装方式（按你用的平台选一种）

### 方式 1：DeepSeek Harness（DSH）
1. 解压本包，得到 `prompt-writing-coach` 文件夹
2. 整个文件夹放到：`C:\Users\Administrator\.agents\skills\`
3. 确认路径是：`C:\Users\Administrator\.agents\skills\prompt-writing-coach\SKILL.md`（SKILL.md 必须在文件夹第一层）
4. 刷新技能目录（重开一个会话即可），在设置面板 → 技能 里能看到它
5. 验证：说"帮我把这段会议纪要整理成待办"，它应直接给出 **ICIO** 提示词，且不问你用什么框架

### 方式 2：Claude Code（或任何支持 Anthropic Skill 格式的 agent）
1. 解压后，把 `prompt-writing-coach` 文件夹放到 `~/.claude/skills/`
2. 确认 `~/.claude/skills/prompt-writing-coach/SKILL.md` 存在
3. 重启会话；提到"写提示词"时它会自动加载

### 方式 3：不支持技能的 AI（ChatGPT / 豆包 / 通义 / 文心 / Claude 网页版 / 各类智能体平台）
1. 打开 `portable/system-prompt.md`，**全文复制**
2. 贴到该平台的「自定义指令 / 系统提示 / 智能体人设 / 角色设定」里
3. 保存后直接说需求即可（例："帮我写个卖保温杯的抖音口播"）

### 方式 4：Cursor / Windsurf / VS Code AI
1. 把 `portable/cursor-rule.mdc` 复制到项目或全局规则目录：
   - Cursor：`.cursor/rules/prompt-writing-coach.mdc`
   - Windsurf：`.windsurf/rules/`
2. 若不想常驻，可把文件里的 `alwaysApply: true` 改成 `false`，改为按需 @ 引用

### 方式 5：Dify / Coze（扣子）/ 其他工作流平台
1. 新建智能体或工作流
2. 把 `portable/system-prompt.md` 全文贴进「系统提示词 / 人设与回复逻辑」
3. 工具与知识库可按需挂载

---

## 装好后的验证清单

- [ ] 说一句："把这段会议纪要整理成待办清单" → 应输出 **ICIO** 结构的提示词，并自带"只依据原文、不编造"的约束
- [ ] 说一句："帮我写个待办清单模板" → 应输出 **RTF** 结构（无输入段）
- [ ] 说一句："卖一款保温杯，给刷到视频的陌生人" → 应选 **AIDA**，不是 PAS
- [ ] 说一句："这几个方案哪个好" → 应选 **ToT**，不是 CoT
- [ ] 全程它**没有**反问你"想用哪个框架"

任何一条不符，说明装错了位置或没生效，按对应方式的路径检查一遍。

---

## 使用示例

> 你：帮我写个提示词，让 AI 把我这段 Python 改成多进程，输出格式别变
> 它：直接给成品（角色 + 任务 + 技术栈约束 + 输出形态 + 验收），首行注明选了什么框架、为什么

> 你：写个带货提示词，卖保温杯，30 秒抖音口播
> 它：直接给口播提示词（AIDA + 3 秒钩子 + 字数/语速/禁用词 + 输出表格）

---

## 更新与卸载

- **更新**：用新版本文件夹整体覆盖，保留目录名不变即可
- **卸载**：删除 `prompt-writing-coach` 文件夹；贴过 system-prompt 的平台，清空对应自定义指令
- **自定义**：想改规矩（比如默认多给一版），直接改 `SKILL.md` 或 `system-prompt.md` 里的对应段落；改完保存即生效

---

## 版权与来源

- 内容整理自本项目 `提示词/` 资料库（框架目录、服务契约、课程手册、实战案例），2026-11-12 定稿
- 可自由复制、修改、内部分发；对外分发建议保留本说明
